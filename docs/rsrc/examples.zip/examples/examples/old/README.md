This folder contains some of the old Faust examples that were using functions from libraries that are considered to not be "standard" anymore. It could be called the "legacy" folder :). Since old Faust libraries are sill implemented using a series `import` of the new libraries, all these files should still work!

## Thoughts

* Maybe the examples based on maxmsp.lib should be in a separate library 