process = + ~(_,.99 : *);
