/* ------------------------------------------------------------
name: "wind"
Code generated with Faust 2.33.0 (https://faust.grame.fr)
Compilation options: -lang cpp -es 1 -single -ftz 0
------------------------------------------------------------ */

#ifndef  __mydsp_H__
#define  __mydsp_H__

#ifndef FAUSTFLOAT
#define FAUSTFLOAT float
#endif 

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <math.h>

static float mydsp_faustpower2_f(float value) {
	return (value * value);
}

#ifndef FAUSTCLASS 
#define FAUSTCLASS mydsp
#endif

#ifdef __APPLE__ 
#define exp10f __exp10f
#define exp10 __exp10
#endif

class mydsp : public dsp {
	
 private:
	
	FAUSTFLOAT fHslider0;
	float fRec0[2];
	int iRec1[2];
	int fSampleRate;
	float fConst0;
	float fRec5[2];
	float fRec3[2];
	float fRec8[2];
	float fRec6[2];
	float fRec11[2];
	float fRec9[2];
	float fRec14[2];
	float fRec12[2];
	
 public:
	
	void metadata(Meta* m) { 
		m->declare("basics.lib/name", "Faust Basic Element Library");
		m->declare("basics.lib/version", "0.1");
		m->declare("compile_options", "-lang cpp -es 1 -single -ftz 0");
		m->declare("filename", "wind.dsp");
		m->declare("filters.lib/allpassnnlt:author", "Julius O. Smith III");
		m->declare("filters.lib/allpassnnlt:copyright", "Copyright (C) 2003-2019 by Julius O. Smith III <jos@ccrma.stanford.edu>");
		m->declare("filters.lib/allpassnnlt:license", "MIT-style STK-4.3 license");
		m->declare("filters.lib/lowpass0_highpass1", "Copyright (C) 2003-2019 by Julius O. Smith III <jos@ccrma.stanford.edu>");
		m->declare("filters.lib/name", "Faust Filters Library");
		m->declare("filters.lib/tf2np:author", "Julius O. Smith III");
		m->declare("filters.lib/tf2np:copyright", "Copyright (C) 2003-2019 by Julius O. Smith III <jos@ccrma.stanford.edu>");
		m->declare("filters.lib/tf2np:license", "MIT-style STK-4.3 license");
		m->declare("filters.lib/version", "0.3");
		m->declare("maths.lib/author", "GRAME");
		m->declare("maths.lib/copyright", "GRAME");
		m->declare("maths.lib/license", "LGPL with exception");
		m->declare("maths.lib/name", "Faust Math Library");
		m->declare("maths.lib/version", "2.3");
		m->declare("name", "wind");
		m->declare("noises.lib/name", "Faust Noise Generator Library");
		m->declare("noises.lib/version", "0.0");
		m->declare("platform.lib/name", "Generic Platform Library");
		m->declare("platform.lib/version", "0.1");
		m->declare("signals.lib/name", "Faust Signal Routing Library");
		m->declare("signals.lib/version", "0.0");
		m->declare("vaeffects.lib/moog_vcf_2bn:author", "Julius O. Smith III");
		m->declare("vaeffects.lib/moog_vcf_2bn:copyright", "Copyright (C) 2003-2019 by Julius O. Smith III <jos@ccrma.stanford.edu>");
		m->declare("vaeffects.lib/moog_vcf_2bn:license", "MIT-style STK-4.3 license");
		m->declare("vaeffects.lib/name", "Faust Virtual Analog Filter Effect Library");
		m->declare("vaeffects.lib/version", "0.0");
	}

	virtual int getNumInputs() {
		return 0;
	}
	virtual int getNumOutputs() {
		return 2;
	}
	
	static void classInit(int sample_rate) {
	}
	
	virtual void instanceConstants(int sample_rate) {
		fSampleRate = sample_rate;
		fConst0 = (3.14159274f / std::min<float>(192000.0f, std::max<float>(1.0f, float(fSampleRate))));
	}
	
	virtual void instanceResetUserInterface() {
		fHslider0 = FAUSTFLOAT(0.66000000000000003f);
	}
	
	virtual void instanceClear() {
		for (int l0 = 0; (l0 < 2); l0 = (l0 + 1)) {
			fRec0[l0] = 0.0f;
		}
		for (int l1 = 0; (l1 < 2); l1 = (l1 + 1)) {
			iRec1[l1] = 0;
		}
		for (int l2 = 0; (l2 < 2); l2 = (l2 + 1)) {
			fRec5[l2] = 0.0f;
		}
		for (int l3 = 0; (l3 < 2); l3 = (l3 + 1)) {
			fRec3[l3] = 0.0f;
		}
		for (int l4 = 0; (l4 < 2); l4 = (l4 + 1)) {
			fRec8[l4] = 0.0f;
		}
		for (int l5 = 0; (l5 < 2); l5 = (l5 + 1)) {
			fRec6[l5] = 0.0f;
		}
		for (int l6 = 0; (l6 < 2); l6 = (l6 + 1)) {
			fRec11[l6] = 0.0f;
		}
		for (int l7 = 0; (l7 < 2); l7 = (l7 + 1)) {
			fRec9[l7] = 0.0f;
		}
		for (int l8 = 0; (l8 < 2); l8 = (l8 + 1)) {
			fRec14[l8] = 0.0f;
		}
		for (int l9 = 0; (l9 < 2); l9 = (l9 + 1)) {
			fRec12[l9] = 0.0f;
		}
	}
	
	virtual void init(int sample_rate) {
		classInit(sample_rate);
		instanceInit(sample_rate);
	}
	virtual void instanceInit(int sample_rate) {
		instanceConstants(sample_rate);
		instanceResetUserInterface();
		instanceClear();
	}
	
	virtual mydsp* clone() {
		return new mydsp();
	}
	
	virtual int getSampleRate() {
		return fSampleRate;
	}
	
	virtual void buildUserInterface(UI* ui_interface) {
		ui_interface->openVerticalBox("wind");
		ui_interface->addHorizontalSlider("force", &fHslider0, 0.660000026f, 0.0f, 1.0f, 0.00999999978f);
		ui_interface->closeBox();
	}
	
	virtual void compute(int count, FAUSTFLOAT** inputs, FAUSTFLOAT** outputs) {
		FAUSTFLOAT* output0 = outputs[0];
		FAUSTFLOAT* output1 = outputs[1];
		float fSlow0 = (0.00300000003f * float(fHslider0));
		for (int i0 = 0; (i0 < count); i0 = (i0 + 1)) {
			fRec0[0] = (fSlow0 + (0.996999979f * fRec0[1]));
			int iTemp0 = (1103515245 * (iRec1[1] + 12345));
			iRec1[0] = (1103515245 * (iTemp0 + 12345));
			int iRec2 = iTemp0;
			float fTemp1 = float(iRec1[0]);
			float fTemp2 = mydsp_faustpower2_f((1.41419947f * fRec0[0]));
			float fTemp3 = (1.99997997f * fRec0[0]);
			float fTemp4 = (fTemp2 + fTemp3);
			float fTemp5 = (fTemp3 + 2.0f);
			float fTemp6 = std::tan((fConst0 * std::max<float>((440.0f * std::pow(2.0f, (0.0833333358f * ((87.0f * fRec0[0]) + -48.0f)))), 20.0f)));
			float fTemp7 = (1.0f / fTemp6);
			float fTemp8 = ((fTemp4 + ((fTemp5 + fTemp7) / fTemp6)) + 1.0f);
			float fTemp9 = ((fTemp4 + (1.0f - ((fTemp5 - fTemp7) / fTemp6))) / fTemp8);
			float fTemp10 = std::max<float>(-0.999999881f, std::min<float>(0.999999881f, fTemp9));
			float fTemp11 = (1.0f - mydsp_faustpower2_f(fTemp10));
			float fTemp12 = std::sqrt(std::max<float>(0.0f, fTemp11));
			float fTemp13 = ((4.65661287e-10f * (fTemp1 * fTemp12)) - (fTemp10 * fRec3[1]));
			float fTemp14 = (1.0f / mydsp_faustpower2_f(fTemp6));
			float fTemp15 = (fTemp4 + (1.0f - fTemp14));
			float fTemp16 = std::max<float>(-0.999999881f, std::min<float>(0.999999881f, (2.0f * (fTemp15 / (fTemp8 * (fTemp9 + 1.0f))))));
			float fTemp17 = (1.0f - mydsp_faustpower2_f(fTemp16));
			float fTemp18 = std::sqrt(std::max<float>(0.0f, fTemp17));
			fRec5[0] = ((fTemp13 * fTemp18) - (fTemp16 * fRec5[1]));
			fRec3[0] = ((fTemp13 * fTemp16) + (fRec5[1] * fTemp18));
			float fRec4 = fRec5[0];
			float fTemp19 = (1.0f - (fTemp15 / fTemp8));
			float fTemp20 = std::sqrt(fTemp11);
			float fTemp21 = ((1.0f - fTemp9) - (2.0f * (fTemp16 * fTemp19)));
			float fTemp22 = (fTemp20 * std::sqrt(fTemp17));
			float fTemp23 = ((((4.65661287e-10f * (fTemp1 * fTemp10)) + (fRec3[1] * fTemp12)) + (2.0f * ((fRec3[0] * fTemp19) / fTemp20))) + ((fRec4 * fTemp21) / fTemp22));
			float fTemp24 = (2.0f - fTemp3);
			float fTemp25 = (1.0f - fTemp3);
			float fTemp26 = ((fTemp2 + ((fTemp7 + fTemp24) / fTemp6)) + fTemp25);
			float fTemp27 = (((fTemp2 + ((fTemp7 - fTemp24) / fTemp6)) + fTemp25) / fTemp26);
			float fTemp28 = std::max<float>(-0.999999881f, std::min<float>(0.999999881f, fTemp27));
			float fTemp29 = (1.0f - mydsp_faustpower2_f(fTemp28));
			float fTemp30 = std::sqrt(std::max<float>(0.0f, fTemp29));
			float fTemp31 = (((fTemp23 * fTemp30) / fTemp8) - (fTemp28 * fRec6[1]));
			float fTemp32 = (fTemp2 + (1.0f - (fTemp3 + fTemp14)));
			float fTemp33 = std::max<float>(-0.999999881f, std::min<float>(0.999999881f, (2.0f * (fTemp32 / (fTemp26 * (fTemp27 + 1.0f))))));
			float fTemp34 = (1.0f - mydsp_faustpower2_f(fTemp33));
			float fTemp35 = std::sqrt(std::max<float>(0.0f, fTemp34));
			fRec8[0] = ((fTemp31 * fTemp35) - (fTemp33 * fRec8[1]));
			fRec6[0] = ((fTemp31 * fTemp33) + (fRec8[1] * fTemp35));
			float fRec7 = fRec8[0];
			float fTemp36 = (1.0f - (fTemp32 / fTemp26));
			float fTemp37 = std::sqrt(fTemp29);
			float fTemp38 = ((1.0f - fTemp27) - (2.0f * (fTemp33 * fTemp36)));
			float fTemp39 = (fTemp37 * std::sqrt(fTemp34));
			output0[i0] = FAUSTFLOAT(((fRec0[0] * (((((fTemp23 * fTemp28) / fTemp8) + (fRec6[1] * fTemp30)) + (2.0f * ((fRec6[0] * fTemp36) / fTemp37))) + ((fRec7 * fTemp38) / fTemp39))) / fTemp26));
			float fTemp40 = float(iRec2);
			float fTemp41 = ((4.65661287e-10f * (fTemp40 * fTemp12)) - (fTemp10 * fRec9[1]));
			fRec11[0] = ((fTemp18 * fTemp41) - (fTemp16 * fRec11[1]));
			fRec9[0] = ((fTemp16 * fTemp41) + (fTemp18 * fRec11[1]));
			float fRec10 = fRec11[0];
			float fTemp42 = ((((4.65661287e-10f * (fTemp40 * fTemp10)) + (fTemp12 * fRec9[1])) + (2.0f * ((fRec9[0] * fTemp19) / fTemp20))) + ((fRec10 * fTemp21) / fTemp22));
			float fTemp43 = (((fTemp30 * fTemp42) / fTemp8) - (fTemp28 * fRec12[1]));
			fRec14[0] = ((fTemp35 * fTemp43) - (fTemp33 * fRec14[1]));
			fRec12[0] = ((fTemp33 * fTemp43) + (fTemp35 * fRec14[1]));
			float fRec13 = fRec14[0];
			output1[i0] = FAUSTFLOAT(((fRec0[0] * (((((fTemp28 * fTemp42) / fTemp8) + (fTemp30 * fRec12[1])) + (2.0f * ((fRec12[0] * fTemp36) / fTemp37))) + ((fRec13 * fTemp38) / fTemp39))) / fTemp26));
			fRec0[1] = fRec0[0];
			iRec1[1] = iRec1[0];
			fRec5[1] = fRec5[0];
			fRec3[1] = fRec3[0];
			fRec8[1] = fRec8[0];
			fRec6[1] = fRec6[0];
			fRec11[1] = fRec11[0];
			fRec9[1] = fRec9[0];
			fRec14[1] = fRec14[0];
			fRec12[1] = fRec12[0];
		}
	}

};

#endif
